# kdtree2
A copy of kd-tree implementation in C++ (and Fortran) by Matthew B. Kennel

However, it is not being maintained here. Please reach out the the original author for more. 

This repo is archived and will not be usable for help.
